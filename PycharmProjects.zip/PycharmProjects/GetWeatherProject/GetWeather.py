#程序目标：获取香港天文台后天的湿度数据，输出到控制台和日志文件

import requests
import time
import datetime
import logging
import traceback

# log文件名./log_2021090815.txt
str_logfile = "./log_" + time.strftime("%Y%m%d") + ".txt"

logging.basicConfig(level=logging.INFO,  # 日志级别
                    filename=str_logfile,  # 文件名
                    filemode="a",  # 追加模式
                    format='%(asctime)s - %(pathname)s[line:%(lineno)d] - %(levelname)s: %(message)s'  # 日志格式
                    )

# hk天文台9天天气查询地址
URL = "http://www.hko.gov.hk/wxinfo/json/one_json_uc.xml"
# GET请求参数为空,有效参数通过cookies传递
# 通过抓包结果获取cookies
cookie_dict = {'fontSize': '0',
             'lang': '1',
             'wwi_fav_list': '1390%7C1488%7C1111%7C191%7C1982%7C1886',
             'displayGensit': 'true'
               }

try:
    # 发送GET请求，地址，cookie，参数
    resp = requests.get(URL, cookies=cookie_dict, params={}, timeout=1)
    resp.raise_for_status()  # 如果响应状态码不是 200，就主动抛出异常
    print("网络连接正常……")
    logging.info("网络连接正常……")
except requests.RequestException as e:
    print("查询天气失败，原因：", e)
    logging.error("查询天气失败，原因：" + e.__str__())
else:
    # 响应内容按utf-8格式读取
    resp.encoding = 'utf-8'
    json_resp = resp.json()
    logging.debug("url返回：" + str(json_resp))
    try:
        # logging.debug("未来9天天气：", json_resp["F9D"])
        # 根据返回的json结构读取数据
        str_weatherForecast = json_resp["F9D"]["WeatherForecast"]
        logging.debug(str_weatherForecast)

        # 确认天数为9
        if len(str_weatherForecast) == 9:
            today = datetime.date.today()
            date_after_tomorrow = str(int(today.strftime("%Y%m%d")) + 2)
            # 遍历9天的数据，找到后天所在节点
            str_minrh = ""
            str_maxrh = ""
            for day_wt in str_weatherForecast:
                str_date = day_wt["ForecastDate"]
                if str_date == date_after_tomorrow:
                    str_minrh = day_wt["ForecastMinrh"]
                    str_maxrh = day_wt["ForecastMaxrh"]

                    print("后天(", str_date, ")湿度为：", str_minrh, "% ~ ", str_maxrh, "%")
                    logging.info("后天(" + str_date + ")湿度为：" + str_minrh + "% ~ " + str_maxrh + "%")
                else:
                    continue
            if str_minrh == "" or str_maxrh == "":
                print("抱歉，未查到后天(" + date_after_tomorrow + ")的湿度")
                logging.error("抱歉，未查到后天(" + date_after_tomorrow + ")的湿度")
        else:
            print("查到的信息结构异常,请检查：", str_weatherForecast)
            logging.warning("查到的信息结构异常,请检查：" + str(str_weatherForecast))
    except KeyError:
        # 读取不到节点, 返回信息结构异常
        print("查到的信息结构异常,请检查：", traceback.format_exc())
        logging.error("查到的信息结构异常，请检查：" + str(json_resp))
    except Exception as e:
        # 其他异常
        print("解析json失败，详情：", traceback.format_exc())
        logging.error("解析json失败，详情：" + str(traceback.format_exc()))




