from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from time import sleep

try:
    # 创建 WebDriver 对象，使用chrome浏览器驱动
    driver = webdriver.Chrome(r'.\chromedriver.exe')
    # 调用WebDriver 对象的get方法 打开网址
    driver.get('https://crypto.com/exchange')
    driver.implicitly_wait(10)
    print("page load done")
except Exception as e:
    print("启动Chrome浏览器访问web站点失败,详情:", e)
else:
    # 获取所有 class="e-tabs__nav-item"的元素
    elements = driver.find_elements_by_css_selector(".e-tabs__nav-item")

    # 遍历元素列表,找出USDC标签栏
    for element in elements:
        if element.text == "USDC":

            # 滚动屏幕,使点击位居中
            locate_y = int(element.location["y"]/2)
            js = str("window.scrollTo(0," + str(locate_y) + ")")
            print("run js script:", js)
            driver.execute_script(js)

            # 等待界面完成刷新
            sleep(1)

            # 模拟鼠标点击div,激活USDC板块
            ActionChains(driver).move_to_element(element).click().perform()
            # 等待界面完成刷新
            sleep(2)
            break

    # 从js编码得知CRO/USDC所在行代码格式
    # <span data-v-2bce60e1="" class="source">CRO</span>
    # <span data-v-2bce60e1="" class="target">/USDC</span>
    # 向上5级为表格tr父节点, 父节点中只有一个button组件,点击跳转交易页面
    elements = driver.find_elements_by_css_selector(".source")
    for element in elements:
        # print(element.get_attribute("outerHTML"))
        if element.text == "CRO":
            print(element.get_attribute("outerHTML"))
            try:
                # 向上搜索第5级父节点 各级分别为 /div/div/div/td/tr
                element = element.find_element_by_xpath("//span[@class='source']/../../../../parent::tr")
                # 在整行tr中找到唯一的button组件
                element = element.find_element_by_css_selector("button[type='button']")

                # 滚动屏幕,使点击位居中
                locate_y = int(element.location["y"] / 2)

                js = str("window.scrollTo(0," + str(locate_y) + ")")
                print("run js script:", js)
                driver.execute_script(js)

                # 点击button打开交易页面,模拟鼠标点击
                print("click the ", element.text, " button, location:", element.location)
                ActionChains(driver).move_to_element(element).click().perform()
                sleep(3)
                # 切换driver到交易页面
                # 依次将driver切换到各个窗口句柄,根据tab页title判断是否为交易页面
                for handle in driver.window_handles:
                    # 先切换到该窗口
                    driver.switch_to.window(handle)
                    print("title of the new window :", driver.title)
                    # 检查title是否正确
                    if 'Buy CRO' in driver.title:
                        # 如果是，那么这时候WebDriver对象就是对应的该窗口，退出循环
                        print("CRO/USDC Trade page opened successfully")
                        break
            except Exception as e:
                print(e)
            break
        else:
            continue

    # 等待5s自动关闭窗口
    sleep(10)
    driver.quit()

